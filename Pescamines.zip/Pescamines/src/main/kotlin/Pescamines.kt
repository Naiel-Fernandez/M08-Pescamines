import java.lang.NumberFormatException

fun main(args: Array<String>) {
    // Valors
    val tauler: Tauler;
    var tablero: Int = 0;
    var mines: Int = 0;
    var x: Int = 0;
    var y: Int = 0;
    var opcio: String;

    // Presentació
    println("Benvolgut al Pescamines");
    println("Aquest joc es com una rèplica del \"Busca Minas\"");
    println("!!!COMENÇEM!!!");

    // Demana un número de l'1 al 26
    var valor = "0";
    while (tablero <= 0 || tablero >= 27) {
        println("Introdueix un número de l'1 al 26 com a mida del tauler");
        valor = readLine() ?: "0";
        try { if (valor.toInt() in 1..26) tablero = valor.toInt();
        } catch (e: NumberFormatException) { return; }
    }

    // Demana un número de mines
    while (mines <= 0 || mines >= tablero * tablero) {
        println("Introdueix un número de $tablero a ${tablero*tablero}");
        valor = readLine() ?: "0";
        try {
            if (valor.toInt() in 1..tablero*tablero) mines = valor.toInt();
        } catch (e: NumberFormatException) { return; }
    }

    // Crea tauler
    tauler = Tauler(tablero, mines);
    tauler.posaMines();

    // Comença el joc
    while (true) {
        // Explica els controls
        println("Que vols fer?\n");
        println("m per marcar o desmarcar una mina");
        println("d per descobrir una casella");
        println("/ff per rendir-te\n\n");
        println(tauler);
        opcio = readLine() ?: "/ff";

        // Comprova rendició / Es rendeix per defecte
        if(opcio == "/ff") {
            println("Fins la pròxima!!");
            tauler.descobreixTauler();
            println(tauler);
            return;
        }

        //Demana posició d'X
        while (x <= 0){
            println("Posició d'X?");
            val text = readLine() ?:"0";
            x = text.toInt();
            if(x<0) {
                println("Només números >= 0 i <= $tablero");
                continue;
            }
        }

        //Demana posició d'Y
        while (y <= 0){
            println("Posició d'Y?");
            val text = readLine() ?:"0";
            y = text.toInt();
            if(y<0) {
                println("Només números >= 0 i <= $tablero");
                continue;
            }
        }

        // Opció al marcar o desmarcar per mines
        if(opcio == "m") tauler.marcaMina(x, y);
        else if (opcio == "d"){
            tauler.descobreixCasella(x, y);
            tauler.comptaMines(x,y);
            if(tauler.hiHaMina(x,y)) {
                println("Has perdido");
                println(tauler);
                return;
            }
        }

        // Verifica si el jugador a guanyat el joc o no
        if(tauler.descobert()) {
            println(tauler)
            println("HAS GANADO!!")
            return
        }
    }
}