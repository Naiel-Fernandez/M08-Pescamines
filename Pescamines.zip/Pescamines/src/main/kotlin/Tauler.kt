
class Tauler(num: Int, nm: Int) {
    var n: Int = num;
    var numeroMines: Int = nm;
    var tauler = Array(n) { Array(n) { Casella() } }

    // Metode para posar mines de forma aleatoria al tauler
    fun posaMines() {
        var x: Int;
        var y: Int;
        var mines = numeroMines;
        while (mines !=0){
            x=(0 until n).random();
            y=(0 until n).random();
            if(!tauler[x][y].getEsMina()) tauler[x][y].setEsMina(); mines--;
        }
    }

    // Metode per comptar les mines al voltant
    fun comptaMines(x:Int, y:Int) {
        var mines:Int = 0;
        var top: Int = 0;
        var bot:Int = 0;
        var left:Int = 0;
        var rigth:Int = 0;

        //Top
        top = if (x==0) 0;
        else x-1;

        //Bot
        bot = if (x==tauler.size-1) tauler.size-1;
        else x+1;

        // Left
        left = if (y==0) 0;
        else y-1;

        //Rigth
        rigth = if (y==tauler.size-1) tauler.size-1;
        else y+1;

        //Contador
        for(i in top..bot){
            for (f in left..rigth) {
                if(tauler[i][f].getEsMina()) mines++;
            }
        }
        tauler[x][y].setMinesVeines(mines)
    }

    // Funció per mostrar el tauler
    fun mostraTauler(){
        for (fila in tauler.indices){
            if (fila == 0) print(0..tauler.size);
            else print(fila);
            for (col in 0 until tauler[0].size){
                print(" .");
            }
        }
    }

    // Metode per veure si hi ha una mina a la casella x y
    fun hiHaMina(x:Int, y:Int): Boolean{ return tauler[x][y].getEsMina() }

    // Metode per descobrir una casella
    fun descobreixCasella(x:Int, y:Int){
        if(! tauler[x][y].getDescoberta()) tauler[x][y].setDescoberta(true);
    }

    // Metode per descubrir tot el tauler
    fun descobreixTauler(){
        for(x in tauler.indices) {
            for (y in tauler.indices) {
                tauler[x][y].setDescoberta(true);
                comptaMines(x, y);
            }
        }
    }

    // Metode per veure una casella si es descoberta
    fun descoberta(x:Int, y:Int):Boolean{ return tauler[x][y].getDescoberta(); }

    // Metode que ens diu si la casella es descoberta o no
    fun descobert():Boolean{
        var minas: Int = 0
        for(x in 0 .. tauler.size) {
            for (y in 0 .. tauler.size) {
                if(tauler[x][y].getDescoberta() && !tauler[x][y].getEsMina()) minas++;
            }
        }
        if (minas==n*n-numeroMines) return true;
        return false;
    }

    // Metode per marcar una casella com a mina
    fun marcaMina(x:Int, y:Int){
        if(tauler[x][y].getMinaMarcada()) tauler[x][y].setMarcaMina(false);
        else tauler[x][y].setMarcaMina(true);
    }

    // Metode que ens diu si la casella es marcada o no
    fun minaMarcada(x:Int, y:Int): Boolean{ return tauler[x][y].getMinaMarcada() }

    // Metode toString
    override fun toString(): String {
        var tabla:String = ""
        for(element in tauler) {
            for (y in tauler.indices) {
                tabla += element[y].toString();
            }
            tabla += "\n";
        }
        return tabla;
    }
}