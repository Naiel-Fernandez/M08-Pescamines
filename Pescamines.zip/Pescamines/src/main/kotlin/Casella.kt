class Casella (
    var descoberta: Boolean = false,
    var marcada: Boolean = false,
    var esMina: Boolean = false,
    var minesVeines: Int = 0,
) {
    override fun toString(): String {
        if (getDescoberta()){
            if(getEsMina()) { return String.format(" # ");
            }else { return  String.format(" $minesVeines "); }
        } else {
            if(getMinaMarcada())  return String.format(" * ");
        }
        return " · ";
    }

    @JvmName("getEsMina1")
    fun getEsMina(): Boolean {
        return esMina;
    }

    @JvmName("setEsMina1")
    fun setEsMina() {
        esMina = true;
    }

    @JvmName("getDescoberta1")
    fun getDescoberta(): Boolean{
        return descoberta;
    }
    @JvmName("setDescoberta1")
    fun setDescoberta(d: Boolean){
        descoberta = d;
    }
    @JvmName("getMinaMarcada1")
    fun getMinaMarcada():Boolean{
        return marcada;
    }
    @JvmName("setMinaMarcada1")
    fun setMarcaMina(mm: Boolean){
        marcada = mm;
    }
    @JvmName("minesVeines")
    fun setMinesVeines(i:Int){
        minesVeines = i;
    }
}